
/**************************************************************************************************/
/*  Copyright (C)   2014-2015                                                                     */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  PengJiade                                                            */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  menu list interface                                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by PengJiade, 2014/09/21
 *
 */


#ifndef _MENU_H_
#define _MENU_H_

#include "linktable.h"

int Help();

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     10

/* data struct and its operations */

typedef struct DataNode
{
    tLinkTableNode * pNext;
    char*   cmd;
    char*   desc;
    int     (*handler)(tLinkTable * head);
} tDataNode;

/* find a cmd in the linklist and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head, char * cmd);
/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * head);
/* initialize cmd list*/
int Init_Cmd();
/* build cmd list*/
int Build_Cmd();
/* run cmd list */
int Run_Cmd();

#endif 

