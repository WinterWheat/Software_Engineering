
/**************************************************************************************************/
/*  Copyright (C)   USTC-SoftwareEngineering@2014-2015                                            */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  PengJiade                                                            */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  menu list interface                                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by PengJiade, 2014/09/21
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

tLinkTable * head = NULL;

/* find a cmd in the linklist and return the datanode pointer */
tDataNode* FindCmd(char * cmd)
{
    if(cmd == NULL)
    {
        return NULL;
    }
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {                                          
        if(!strcmp(pNode->cmd, cmd))
        {
            return  pNode;  
        }
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    if(pNode == NULL)
    {
        return NULL;
    }
}

/* show all cmd in listlist */
int ShowAllCmd()
{
    if(head == NULL)
    {
        return FAILURE;
    }
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return  SUCCESS;
}


int Init_Cmd( )
{
    head = CreateLinkTable();
    if(head == NULL)
    {
        return FAILURE;
    }               
    return SUCCESS;
}

int Build_Cmd(tDataNode *data, int Data_Num)
{
    int counter;
    int ret;
    counter = 0;
    while(counter < Data_Num)
    {
        ret = AddLinkTableNode(head,(tLinkTableNode *)&data[counter]);
        if(ret == FAILURE)
        {
        	return FAILURE;
        }
        counter++;
    }
    return SUCCESS;
}

int Run_Cmd()
{
    char cmd[CMD_MAX_LEN];
    while(1)
    {
        printf("Input a cmd number > ");
        scanf("%s", cmd);
        tDataNode *p = FindCmd(cmd);
        if( p == NULL)
        {
            printf("This is a wrong cmd!\n ");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc); 
        if(p->handler != NULL) 
        { 
            p->handler(head);
        }
    }
    return SUCCESS;
}

int Help(tLinkTable * head)
{
    ShowAllCmd(head);
    return 0; 
}
