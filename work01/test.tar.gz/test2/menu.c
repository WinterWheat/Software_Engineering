
/**************************************************************************************************/
/*  Copyright (C)   2014-2015                                                                     */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  PengJiade                                                            */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  menu list interface                                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by PengJiade, 2014/09/21
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

tLinkTable * head = NULL;

/* find a cmd in the linklist and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head, char * cmd)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {                                          
        if(!strcmp(pNode->cmd, cmd))
        {
            return  pNode;  
        }
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return NULL;
}

/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * head)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return 0;
}


int Init_Cmd( )
{
    head = CreateLinkTable();
    if(head == NULL)
    {
        printf("cmd list initializing error!\n");
    }               
    return 0;
}

int Build_Cmd(tDataNode *data, int Data_Num)
{
    int counter;
    counter = 0;
    while(counter < Data_Num)
    {
        AddLinkTableNode(head,(tLinkTableNode *)&data[counter]);
        counter++;
    }
    return 0;
}

int Run_Cmd()
{
    char cmd[CMD_MAX_LEN];
    while(1)
    {
        printf("Input a cmd number > ");
        scanf("%s", cmd);
        tDataNode *p = FindCmd(head, cmd);
        if( p == NULL)
        {
            printf("This is a wrong cmd!\n ");
        }
        printf("%s - %s\n", p->cmd, p->desc); 
        if(p->handler != NULL) 
        { 
            p->handler(head);
        }
    }
}

int Help(tLinkTable * head)
{
    ShowAllCmd(head);
    return 0; 
}
