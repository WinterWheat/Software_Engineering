
/**************************************************************************************************/
/*  Copyright (C)   2014-2015                                                                     */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  PengJiade                                                            */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  this is test program of menu list                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by PengJiade, 2014/09/21
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

#define Data_Num 2
static tDataNode data[Data_Num] = 
{
    {NULL, "help", "this is help cmd!", Help},
    {NULL, "version", "menu program v1.0", NULL}
};

main()
{ 
	Init_Cmd();
    Build_Cmd(data,Data_Num);  
    Run_Cmd();
}

