This is a test program of packaged menu!

Build Procedure
    $ make all
    $ ./test
    $ make clean
