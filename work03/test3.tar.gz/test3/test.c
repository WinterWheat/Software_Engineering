
/**************************************************************************************************/
/*  Copyright (C)   USTC-SoftwareEngineering@2014-2015                                            */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  PengJiade                                                            */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  this is test program of menu list                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by PengJiade, 2014/09/21
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

#define debug printf
#define Data_Num 2
#define TestNum 5 

int results[TestNum] = {1,1,1,1,1};
char * info[TestNum] =
{
    "test report",
    "TC1 Init Cmd",
    "TC2 Build Cmd",
    "TC3 Show Cmd",
    "TC4 Find Cmd"
};

static tDataNode data[Data_Num] = 
{
    {NULL, "help", "this is help cmd!", Help},
    {NULL, "version", "menu program v1.0", NULL}
};

main()
{ 
    int ret;
    int i;
    int count = 0;
    char cmd[100];
	ret = Init_Cmd();
	if(ret == FAILURE)
	{
	    debug("TC1 fail\n");
	    results[1] = ret;
	}
    ret = Build_Cmd(data,Data_Num); 
    if(ret == FAILURE)
    {
        debug("TC2 fail\n");
        results[2] = ret;
    } 
    printf("\nShow all cmd\n");
    ret = ShowAllCmd();
    if(ret == FAILURE)
    {
        debug("TC3 fail\n");
        results[3] = ret;
    } 
    printf("\nTest find cmd:\n");
    printf("Input a cmd:");
    scanf("%s",cmd);
    tDataNode* p = FindCmd(cmd);
    char cmd1[10] = "help";
    char cmd2[10] = "version";
    if(!strcmp(cmd1,cmd)||!strcmp(cmd2,cmd))
    {
        if(p == NULL)
        {
            debug("TC4 fail\n");
            results[4] = -1;
        }
    } 
    else if(p != NULL)
    {
        debug("TC4 fail\n");
        results[4] = -1;
    }
    printf("\nTest Report:\n");
    for(i=1; i<=TestNum-1; i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number %d T - %s\n", i, info[i]);
        }
        else
        {
            printf("Testcase Number %d F - %s\n", i, info[i]);
            count++;
        }
    }
    printf("\nTest Results:\n");
    printf("%d cases tested, %d cases failed\n", TestNum-1, count);
}

