This is a test program of packaged menulist!

Build Procedure
    $ gcc linktable.c menu.c test .c -o test
    $ ./test # you can input help & version cmd.
